<?php
// register post type case
add_action( 'init', 'register_printress_case' );
function register_printress_Case() {
    $labels = array( 
        'name' => __( 'All Case', 'printress' ),
        'singular_name' => __( 'All Case', 'printress' ),
        'add_new' => __( 'Add New Case', 'printress' ),
        'add_new_item' => __( 'Add New Case', 'printress' ),
        'edit_item' => __( 'Edit Case', 'printress' ),
        'new_item' => __( 'New Case', 'printress' ),
        'view_item' => __( 'View Case', 'printress' ),
        'search_items' => __( 'Search Case', 'printress' ),
        'not_found' => __( 'No Case found', 'printress' ),
        'not_found_in_trash' => __( 'No Case found in Trash', 'printress' ),
        'parent_item_colon' => __( 'Parent Case:', 'printress' ),
        'menu_name' => __( 'Case', 'printress' ),
    );
    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Case',
        'supports' => array( 'title', 'authors','editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'case', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-embed-post', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
    register_post_type( 'case', $args );
}
add_action( 'init', 'create_type_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_type_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
  $labels = array(
    'name' => __( 'Type', 'printress' ),
    'singular_name' => __( 'type', 'printress' ),
    'search_items' =>  __( 'Search type','printress' ),
    'all_items' => __( 'All type','printress' ),
    'parent_item' => __( 'Parent type','printress' ),
    'parent_item_colon' => __( 'Parent type:','printress' ),
    'edit_item' => __( 'Edit type','printress' ), 
    'update_item' => __( 'Update type','printress' ),
    'add_new_item' => __( 'Add New type','printress' ),
    'new_item_name' => __( 'New type Name','printress' ),
    'menu_name' => __( 'Type','printress' ),
  );     
// Now register the taxonomy
  register_taxonomy('type',array('Case'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));
}

// register post type1 service
add_action( 'init', 'register_printress_service' );
function register_printress_service() {
    $labels = array( 
        'name' => __( 'All Service', 'printress' ),
        'singular_name' => __( 'All Service', 'printress' ),
        'add_new' => __( 'Add New Service', 'printress' ),
        'add_new_item' => __( 'Add New Service', 'printress' ),
        'edit_item' => __( 'Edit Service', 'printress' ),
        'new_item' => __( 'New Service', 'printress' ),
        'view_item' => __( 'View Service', 'printress' ),
        'search_items' => __( 'Search Service', 'printress' ),
        'not_found' => __( 'No Service found', 'printress' ),
        'not_found_in_trash' => __( 'No service found in Trash', 'printress' ),
        'parent_item_colon' => __( 'Parent Service:', 'printress' ),
        'menu_name' => __( 'Service', 'printress' ),
    );
    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Service',
        'supports' => array( 'title', 'authors','editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'service', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-embed-post', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
    register_post_type( 'service', $args );
}
add_action( 'init', 'create_type1_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_type1_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
  $labels = array(
    'name' => __( 'Type 1', 'printress' ),
    'singular_name' => __( 'type1', 'printress' ),
    'search_items' =>  __( 'Search type 1','printress' ),
    'all_items' => __( 'All type 1','printress' ),
    'parent_item' => __( 'Parent type 1','printress' ),
    'parent_item_colon' => __( 'Parent type 1:','printress' ),
    'edit_item' => __( 'Edit type 1','printress' ), 
    'update_item' => __( 'Update type 1','printress' ),
    'add_new_item' => __( 'Add New type 1','printress' ),
    'new_item_name' => __( 'New type 1 Name','printress' ),
    'menu_name' => __( 'Type1','printress' ),
  );
// Now register the taxonomy
  register_taxonomy('type1',array('service'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));
}

// register post type2 service
add_action( 'init', 'register_printress_team' );
function register_printress_team() {
    $labels = array( 
        'name' => __( 'All Team', 'printress' ),
        'singular_name' => __( 'All Team', 'printress' ),
        'add_new' => __( 'Add New Team', 'printress' ),
        'add_new_item' => __( 'Add New Team', 'printress' ),
        'edit_item' => __( 'Edit Team', 'printress' ),
        'new_item' => __( 'New Team', 'printress' ),
        'view_item' => __( 'View Team', 'printress' ),
        'search_items' => __( 'Search Team', 'printress' ),
        'not_found' => __( 'No Team found', 'printress' ),
        'not_found_in_trash' => __( 'No team found in Trash', 'printress' ),
        'parent_item_colon' => __( 'Parent Team:', 'printress' ),
        'menu_name' => __( 'Team', 'printress' ),
    );
    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Team',
        'supports' => array( 'title', 'authors','editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'team', 'type2' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-embed-post', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_type' => 'post'
    );
    register_post_type( 'team', $args );
}
add_action( 'init', 'create_type2_hierarchical_taxonomy', 0 );
//create a custom taxonomy name it Skillss for your posts
function create_type2_hierarchical_taxonomy() {
// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI
  $labels = array(
    'name' => __( 'Type 2', 'printress' ),
    'singular_name' => __( 'type2', 'printress' ),
    'search_items' =>  __( 'Search type 2','printress' ),
    'all_items' => __( 'All type 2','printress' ),
    'parent_item' => __( 'Parent type 2','printress' ),
    'parent_item_colon' => __( 'Parent type 2:','printress' ),
    'edit_item' => __( 'Edit type 2','printress' ), 
    'update_item' => __( 'Update type 2','printress' ),
    'add_new_item' => __( 'Add New type 2','printress' ),
    'new_item_name' => __( 'New type 2 Name','printress' ),
    'menu_name' => __( 'Type2','printress' ),
  );
// Now register the taxonomy
  register_taxonomy('type2',array('team'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type2' ),
  ));
}