<?php
/**
 * Plugin Name: Meta Box
 * Plugin URI:  https://metabox.io
 * Description: Create custom meta boxes and custom fields in WordPress.
 * Version:     5.3.3
 * Author:      MetaBox.io
 * Author URI:  https://metabox.io
 * License:     GPL2+
 * Text Domain: meta-box
 * Domain Path: /languages/
 * 
 * @package Meta Box
 */

if ( defined( 'ABSPATH' ) && ! defined( 'RWMB_VER' ) ) {
    register_activation_hook( __FILE__, 'rwmb_check_php_version' );

    /**
     * Display notice for old PHP version.
     */
    function rwmb_check_php_version() {
        if ( version_compare( phpversion(), '5.3', '<' ) ) {
            die( esc_html__( 'Meta Box requires PHP version 5.3+. Please contact your host to upgrade.', 'meta-box' ) );
        }
    }




    require_once dirname( __FILE__ ) . '/inc/loader.php';
    $rwmb_loader = new RWMB_Loader();
    $rwmb_loader->init();


    add_filter( 'rwmb_meta_boxes', function ( $meta_boxes ) {

    $prefix = '_cmb_';


    //Add other metaboxs as needed

    


  // Open Code


    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Content Excerpt Blog Standard',
                'desc' => 'Content excerpt show in blog standard',
                'default' => '',
                'id' => $prefix . 'content_excerpt',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Title Excerpt show in other page',
                'desc' => 'Title excerpt show in other page',
                'default' => '',
                'id' => $prefix . 'title_excerpt',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Show in sidebar Recent post',
                'desc' => 'Show in sidebar',
                'default' => '',
                'id' => $prefix . 'image_recent',
                'type' => 'file'
            ),
        )
    );


    $meta_boxes[] = array(
        'id'         => 'service_setting',
        'title'      => 'Service Setting',
        'pages'      => array('service'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Price Service',
                'desc' => 'Price service show in other page',
                'default' => '',
                'id' => $prefix . 'price_service',
                'type' => 'text'
            ),
            array(
                'name' => 'Recent Icon Service',
                'desc' => 'Show in service page and home page',
                'default' => '',
                'id' => $prefix . 'image_service_recent',
                'type' => 'textarea'
            ), 
        )
    );


    $meta_boxes[] = array(
        'id'         => 'team_setting',
        'title'      => 'Team Setting',
        'pages'      => array('team'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Job',
                'desc' => 'Job show in page',
                'default' => '',
                'id' => $prefix . 'team_job',
                'type' => 'text'
            ),
            array(
                'name' => 'Phone text',
                'desc' => 'Phone text show in single team',
                'default' => 'Phone',
                'id' => $prefix . 'team_phone_1',
                'type' => 'text'
            ),
            array(
                'name' => 'Phone number',
                'desc' => 'Phone text show in single team',
                'default' => 'Phone',
                'id' => $prefix . 'team_phone_2',
                'type' => 'text'
            ),
            array(
                'name' => 'Email text',
                'desc' => 'Email text show in single team',
                'default' => 'Email',
                'id' => $prefix . 'team_email_1',
                'type' => 'text'
            ),
            array(
                'name' => 'Email address',
                'desc' => 'Email address show in single team',
                'default' => 'raymon@gmail.com',
                'id' => $prefix . 'team_email_2',
                'type' => 'text'
            ),
            array(
                'name' => 'Social text',
                'desc' => 'Social text show in single team',
                'default' => 'Social',
                'id' => $prefix . 'team_social_text',
                'type' => 'text'
            ),
            array(
                'name' => 'Social Networks 1',
                'desc' => 'Social networks 1 show in page',
                'default' => '',
                'id' => $prefix . 'social_1',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Social Networks 2',
                'desc' => 'Social networks 2 show in page',
                'default' => '',
                'id' => $prefix . 'social_2',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Social Networks 3',
                'desc' => 'Social networks 3 show in page',
                'default' => '',
                'id' => $prefix . 'social_3',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Social Networks 4',
                'desc' => 'Social networks 4 show in page',
                'default' => '',
                'id' => $prefix . 'social_4',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Social Networks 5',
                'desc' => 'Social networks 5 show in page',
                'default' => '',
                'id' => $prefix . 'social_5',
                'type' => 'textarea'
            ),
        )
    );

    $meta_boxes[] = array(
        'id'         => 'case_setting',
        'title'      => 'Case Setting',
        'pages'      => array('case'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        'fields' => array(
            array(
                'name' => 'Show in Case page',
                'desc' => 'Show in case page',
                'default' => '',
                'id' => $prefix . 'case_thumbnail_2',
                'type' => 'file'
            ),
            array(
                'name' => 'Show in Home page',
                'desc' => 'Show in home page',
                'default' => '',
                'id' => $prefix . 'case_thumbnail_3',
                'type' => 'file'
            ),
        )
    );


// End Code
    return $meta_boxes;
});
}