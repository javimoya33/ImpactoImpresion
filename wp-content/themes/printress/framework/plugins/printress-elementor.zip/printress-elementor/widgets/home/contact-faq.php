<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsContactFAQ extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-contact-faq';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home - Contact FAQ', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-columns';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'contactfaq', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_contact_faq',
			[
				'label' => esc_html__( 'Home - Contact FAQ', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading_1',
			[
				'label'       => __( 'Text Heading Left', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text heading left', 'bdevs-elementor' ),
				'default'     => __( 'Contact Us', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title_1',
			[
				'label'       => __( 'Text Title Left', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text title left', 'bdevs-elementor' ),
				'default'     => __( 'Give Us A Printing <br> Deal From Company', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'shortcode_form',
			[
				'label'       => __( 'Shortcode Contact Us Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your shortcode contact form', 'bdevs-elementor' ),
				'default'     => __( '[contact-form-7 id="124" title="Contact Form"]', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'heading_2',
			[
				'label'       => __( 'Text Heading Right', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text heading right', 'bdevs-elementor' ),
				'default'     => __( 'Faq', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title_2',
			[
				'label'       => __( 'Text Title Right', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text title right', 'bdevs-elementor' ),
				'default'     => __( 'Our Experience Spans <br> Every Industry', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Content FAQ Accordion Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'        => 'item_question',
						'label'       => esc_html__( 'Text Question Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Question' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_answer',
						'label'       => esc_html__( 'Text Answer Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Answer' , 'bdevs-elementor' ),
						'label_block' => true,
					],
				],
			]
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->add_control(
			'show_heading_1',
			[
				'label'   => esc_html__( 'Show Heading 1', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title_1',
			[
				'label'   => esc_html__( 'Show Title 1', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_heading_2',
			[
				'label'   => esc_html__( 'Show Heading 2', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title_2',
			[
				'label'   => esc_html__( 'Show Title 2', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="bd-contact-faq pt-120">
	<div class="container">
		<div class="row wow fadeInUp" data-wow-delay=".3s">
			<div class="col-lg-6">
				<div class="bd-contact__wrapper mb-120">
					<div class="bd-section__title mb-50">
						<?php if (( '' !== $settings['heading_1'] ) && ( $settings['show_heading_1'] )): ?>
							<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading_1']); ?></span>
						<?php endif; ?>
						<?php if (( '' !== $settings['title_1'] ) && ( $settings['show_title_1'] )): ?>
							<h2 class="bd__title-sm"><?php echo wp_kses_post($settings['title_1']); ?></h2>
						<?php endif; ?>
					</div>
					<div class="bd-contact__form">
						<?php echo do_shortcode($settings['shortcode_form']); ?>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="bd-faq__wrapper bd-faq__padd2 mb-120">
					<div class="bd-section__title mb-50">
						<?php if (( '' !== $settings['heading_2'] ) && ( $settings['show_heading_2'] )): ?>
							<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading_2']); ?></span>
						<?php endif; ?>
						<?php if (( '' !== $settings['title_2'] ) && ( $settings['show_title_2'] )): ?>
							<h2 class="bd__title-sm"><?php echo wp_kses_post($settings['title_2']); ?></h2>
						<?php endif; ?>
					</div>
					<div class="accordion" id="accordionExample">
						<?php 
						$i = 0;
						foreach ( $settings['tabs'] as $item ) : 
							$i++;
						?>
							<div class="accordion-item">
								<h2 class="accordion-header" id="heading<?php echo esc_attr($i) ; ?>">
									<?php if ($i == 1) { ?>
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($i) ; ?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i) ; ?>">
									<?php } else { ?>
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($i) ; ?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i) ; ?>">
									<?php } ?>
											<?php echo wp_kses_post($item['item_question']); ?>
										</button>
								</h2>
								<?php if ($i == 1) { ?>
									<div id="collapse<?php echo esc_attr($i) ; ?>" class="accordion-collapse collapse show" aria-labelledby="heading<?php echo esc_attr($i) ; ?>" data-bs-parent="#accordionExample">
								<?php } else { ?>
									<div id="collapse<?php echo esc_attr($i) ; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo esc_attr($i) ; ?>" data-bs-parent="#accordionExample">
								<?php } ?>
										<div class="accordion-body">
											<p><?php echo wp_kses_post($item['item_answer']); ?></p>
										</div>
									</div>

							</div>
						<?php endforeach; ?>
					 </div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
}

}