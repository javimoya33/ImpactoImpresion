<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHomeBannerThree extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-banner-three';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home Banner Three', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slider-full-screen';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'homebannerthree', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_home_banner_three',
			[
				'label' => esc_html__( 'Home Banner Three', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Content Testimonials Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'        => 'item_bg',
						'label'       => esc_html__( 'Background Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::MEDIA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_heading',
						'label'       => esc_html__( 'Heading Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Welcome To Our Company' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_title',
						'label'       => esc_html__( 'Title Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'First & Quality <br> Printing Press' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_link_btn_1',
						'label'       => esc_html__( 'Link Button 1 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_btn_1',
						'label'       => esc_html__( 'Text Button 1 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Make An Order' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_link_btn_2',
						'label'       => esc_html__( 'Link Button 2 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_btn_2',
						'label'       => esc_html__( 'Text Button 2 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'How It Work' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_star_1',
						'label'       => esc_html__( 'Rating 1 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'		  => '1',
						'max'		  => '5',
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '5' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_number_rate_1',
						'label'       => esc_html__( 'Number Rate 1 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '4.8' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_rate_1',
						'label'       => esc_html__( 'Text Rate 1 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Best Rated' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_star_2',
						'label'       => esc_html__( 'Rating 2 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'		  => '1',
						'max'		  => '5',
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '5' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_number_rate_2',
						'label'       => esc_html__( 'Number Rate 2 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '<span>1M</span><sup>+</sup>' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_rate_2',
						'label'       => esc_html__( 'Text Rate 2 Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Best Rated' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_btn_1',
			[
				'label'   => esc_html__( 'Show Button 1', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_btn_2',
			[
				'label'   => esc_html__( 'Show Button 2', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<div class="banner-area banner-area1 pos-rel white-bg-2">
	<div class="swiper-container slider__active">
		<div class="swiper-wrapper">
			<?php
			foreach ( $settings['tabs'] as $item ) : 
			?>
				<div class="swiper-slide">
					<div class="single-banner single-banner-3 bd-red__overlay banner-970 d-flex align-items-center pos-rel">
						<div class="banner-bg banner-bg3 bg-css" data-background="<?php echo wp_kses_post($item['item_bg']['url']); ?>">
						</div>
						<div class="container pos-rel">
							<div class="row align-items-center">
								<div class="col-xl-7 col-lg-7">
									<div class="banner-content banner-content3 p-relative">
										<?php if (( '' !== $item['item_heading'] ) && ( $settings['show_heading'] )): ?>
											<div class="banner-meta-text white-color" data-animation="fadeInUp" data-delay=".3s">
												<span><?php echo wp_kses_post($item['item_heading']); ?></span>
											</div>
										<?php endif; ?>
										<?php if (( '' !== $item['item_title'] ) && ( $settings['show_title'] )): ?>
											<h1 class="banner-title white-color" data-animation="fadeInUp" data-delay=".5s">
												<?php echo wp_kses_post($item['item_title']); ?>
											</h1>
										<?php endif; ?>
										<div class="banner-btn three mt-50" data-animation="fadeInUp" data-delay=".7s">
											<?php if (( '' !== $item['item_link_btn_1'] ) && ( '' !== $item['item_text_btn_1'] ) && ( $settings['show_btn_1'] )): ?>
												<a class="theme-btn black" href="<?php echo wp_kses_post($item['item_link_btn_1']); ?>">
													<?php echo wp_kses_post($item['item_text_btn_1']); ?>
													<i class="fal fa-arrow-alt-right"></i>
												</a>
											<?php endif; ?>
											<?php if (( '' !== $item['item_link_btn_2'] ) && ( '' !== $item['item_text_btn_2'] ) && ( $settings['show_btn_2'] )): ?>
												<a class="theme-btn white" href="<?php echo wp_kses_post($item['item_link_btn_2']); ?>">
													<?php echo wp_kses_post($item['item_text_btn_2']); ?>
													<i class="fal fa-arrow-alt-right"></i>
												</a>
											<?php endif; ?>
										</div>
										<div class="bd-rating-area">
											<div class="bd-rating-item one white-bg bd-hover-top" data-animation="fadeInUp" data-delay=".9s">
												<div class="bd-rating-icon">
													<?php for ($i=1; $i <= 5; $i++) {?>
														<?php if ($i <= $item['item_star_1']) { ?>
															<i class="fas fa-star"></i>
														<?php } else { ?>
															<i class="fas fa-star gray"></i>
														<?php } ?>
													<?php } ?>
												</div>
												<h2 class="bd-rating-title">
													<?php echo wp_kses_post($item['item_number_rate_1']); ?>
												</h2>
												<span class="bd-rating-text">
													<?php echo wp_kses_post($item['item_text_rate_1']); ?>
												</span>
											</div>
											<div class="bd-rating-item two black-bg bd-hover-top" data-animation="fadeInUp" data-delay="1.1s">
												<div class="bd-rating-icon">
													<?php for ($i=1; $i <= 5; $i++) {?>
														<?php if ($i <= $item['item_star_2']) { ?>
															<i class="fas fa-star"></i>
														<?php } else { ?>
															<i class="fas fa-star gray"></i>
														<?php } ?>
													<?php } ?>
												</div>
												<h2 class="bd-rating-title">
													<?php echo wp_kses_post($item['item_number_rate_2']); ?>
												</h2>
												<span class="bd-rating-text">
													<?php echo wp_kses_post($item['item_text_rate_2']); ?>
												</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<?php
}
}