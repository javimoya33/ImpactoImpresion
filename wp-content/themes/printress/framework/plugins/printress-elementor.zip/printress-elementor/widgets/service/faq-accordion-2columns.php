<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFaqAccordion2Columns extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-faq-accordion-2columns';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ - Accordion 2 Columns', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-help';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'faqaccordion2columns', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_faq_accordion_2columns',
			[
				'label' => esc_html__( 'FAQ - Accordion 2 Columns', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading',
			[
				'label'       => __( 'Text Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text heading', 'bdevs-elementor' ),
				'default'     => __( 'Faq', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Text Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text title', 'bdevs-elementor' ),
				'default'     => __( 'Common Question Answer', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Content Element Contact Info Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'        => 'item_question',
						'label'       => esc_html__( 'Text Question Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Question' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_answer',
						'label'       => esc_html__( 'Text Answer Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Answer' , 'bdevs-elementor' ),
						'label_block' => true,
					],
				],
			]
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="bd-contact-faq pt-120 pb-60">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="bd-section__title mb-50 text-center">
					<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>
						<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading']); ?></span>
					<?php endif; ?>
					<?php if (( '' !== $settings['title'] ) && ( $settings['show_title'] )): ?>
						<h2 class="bd__title-sm"><?php echo wp_kses_post($settings['title']); ?></h2>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row wow fadeInUp" data-wow-delay=".3s">
			<div class="col-lg-6">
				<div class="bd-faq__wrapper bd-faq__padd2 mb-60">
					<div class="accordion" id="accordionExample">
						<?php 
						$i = 0;
						foreach ( $settings['tabs'] as $item ) : 
							$i++;
						?>
						<?php if ($i % 2 == 1): ?>
							<div class="accordion-item">
								<h2 class="accordion-header" id="heading<?php echo esc_attr($i) ; ?>">
									<?php if ($i == 1) { ?>
										<button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($i) ; ?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i) ; ?>">
									<?php } else { ?>
										<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($i) ; ?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i) ; ?>">
									<?php } ?>
											<?php echo wp_kses_post($item['item_question']); ?>
										</button>
								</h2>
								<?php if ($i == 1) { ?>
									<div id="collapse<?php echo esc_attr($i) ; ?>" class="accordion-collapse collapse show" aria-labelledby="heading<?php echo esc_attr($i) ; ?>" data-bs-parent="#accordionExample">
								<?php } else { ?>
									<div id="collapse<?php echo esc_attr($i) ; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo esc_attr($i) ; ?>" data-bs-parent="#accordionExample">
								<?php } ?>
										<div class="accordion-body">
											<p>
												<?php echo wp_kses_post($item['item_answer']); ?>
											</p>
										</div>
									</div>
							</div>
						<?php endif ?>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="bd-faq__wrapper bd-faq__padd2 mb-60">
					<div class="accordion" id="accordionExample2">
						<?php 
						$i = 0;
						foreach ( $settings['tabs'] as $item ) : 
							$i++;
						?>
						<?php if ($i % 2 == 0): ?>
							<div class="accordion-item">
								<h2 class="accordion-header" id="heading<?php echo esc_attr($i) ; ?>">
									<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($i) ; ?>" aria-expanded="true" aria-controls="collapse<?php echo esc_attr($i) ; ?>">
										<?php echo wp_kses_post($item['item_question']); ?>
									</button>
								</h2>
								<div id="collapse<?php echo esc_attr($i) ; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo esc_attr($i) ; ?>" data-bs-parent="#accordionExample2">
									<div class="accordion-body">
										<p>
											<?php echo wp_kses_post($item['item_answer']); ?>
										</p>
									</div>
								</div>
							</div>
						<?php endif; ?>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
}

}