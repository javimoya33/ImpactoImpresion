<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPricingTable extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-pricing-table';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricng - Pricing Table', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'pricingtable', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_pricing_table',
			[
				'label' => esc_html__( 'Pricing - Pricing Table', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading',
			[
				'label'       => __( 'Text Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text heading', 'bdevs-elementor' ),
				'default'     => __( 'Pricing Table', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Text Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text title', 'bdevs-elementor' ),
				'default'     => __( 'Choose Your Best Plan', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'text_gr_1',
			[
				'label'       => __( 'Text Group 1', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text group 1', 'bdevs-elementor' ),
				'default'     => __( 'Monthly', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'tabs1',
			[
				'label' => esc_html__( 'Content Group Items 1', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'        	=> 'item_acitve',
						'label'     	=> esc_html__( 'Active Item', 'bdevs-elementor' ),
						'type'      	=> Controls_Manager::SELECT,
						'options'   	=> [
							'active'  	=> esc_html__( 'Active', 'bdevs-elementor' ),
							''			=> esc_html__( 'No Active', 'bdevs-elementor' ),
						],
						'default'   	=> '',
					],
					[
						'name'        => 'item_text_active',
						'label'       => esc_html__( 'Text Active Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Popular' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_title',
						'label'       => esc_html__( 'Text Title Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title Item' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_currency',
						'label'       => esc_html__( 'Currency Unit Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '$' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_price_1',
						'label'       => esc_html__( 'Item Price 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'     	  => 0,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '0' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_price_2',
						'label'       => esc_html__( 'Item Price 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'     	  => 0,
						'max'     	  => 100,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '0' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_content',
						'label'       => esc_html__( 'Text Content Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content Item' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_link_btn',
						'label'       => esc_html__( 'Text Link Button Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_btn',
						'label'       => esc_html__( 'Text Button Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Get Started' , 'bdevs-elementor' ),
						'label_block' => true,
					],
				],
			]
		);

		$this->add_control(
			'text_gr_2',
			[
				'label'       => __( 'Text Group 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text group 2', 'bdevs-elementor' ),
				'default'     => __( 'Yearly', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'tabs2',
			[
				'label' => esc_html__( 'Content Group Items 2', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Slide #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					]
				],
				'fields' => [
					[
						'name'        	=> 'item_acitve',
						'label'     	=> esc_html__( 'Active Item', 'bdevs-elementor' ),
						'type'      	=> Controls_Manager::SELECT,
						'options'   	=> [
							'active'  	=> esc_html__( 'Active', 'bdevs-elementor' ),
							''			=> esc_html__( 'No Active', 'bdevs-elementor' ),
						],
						'default'   	=> '',
					],
					[
						'name'        => 'item_text_active',
						'label'       => esc_html__( 'Text Active Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Popular' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_title',
						'label'       => esc_html__( 'Text Title Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title Item' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_currency',
						'label'       => esc_html__( 'Currency Unit Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '$' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_price_1',
						'label'       => esc_html__( 'Item Price 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'     	  => 0,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '0' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_price_2',
						'label'       => esc_html__( 'Item Price 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::NUMBER,
						'min'     	  => 0,
						'max'     	  => 100,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '0' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_content',
						'label'       => esc_html__( 'Text Content Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content Item' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_link_btn',
						'label'       => esc_html__( 'Text Link Button Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'item_text_btn',
						'label'       => esc_html__( 'Text Button Item', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Get Started' , 'bdevs-elementor' ),
						'label_block' => true,
					],
				],
			]
		);

		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="pricing__area white-bg-2 pt-120 pb-85">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7">
				<div class="bd-section__title mb-50 text-center">
					<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>
						<span class="bd__subtitle"><span><?php echo wp_kses_post($settings['heading']); ?></span></span>
					<?php endif; ?>
					<?php if (( '' !== $settings['title'] ) && ( $settings['show_title'] )): ?>
						<h2 class="bd__title"><span><?php echo wp_kses_post($settings['title']); ?></span></h2>
					<?php endif; ?>
				</div>
				<div class="pricing-tab mb-75">
					<ul class="nav nav-tabs justify-content-center" id="priceTab" role="tablist">
						<li class="nav-item" role="presentation">
							<button class="nav-link active" id="monthly-tab" data-bs-toggle="tab" data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly" aria-selected="true">
								<?php echo wp_kses_post($settings['text_gr_1']); ?>
							</button>
						</li>
						<li class="nav-item" role="presentation">
							<button class="nav-link" id="yearly-tab" data-bs-toggle="tab" data-bs-target="#yearly" type="button" role="tab" aria-controls="yearly" aria-selected="false">
								<?php echo wp_kses_post($settings['text_gr_2']); ?>
							</button>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="tab-content" id="priceTabContent">
			<div class="tab-pane fade active show" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
				<div class="row">
					<?php 
					foreach ( $settings['tabs1'] as $item1 ) : 
					?>
						<div class="col-lg-4 col-md-6">
							<div class="pricing__box <?php echo wp_kses_post($item1['item_acitve']); ?> mb-50">
								<div class="pricing__header">
									<?php if ($item1['item_acitve'] == 'active'): ?>
										<div class="pricing__badge">
											<span><?php echo wp_kses_post($item1['item_text_active']); ?></span>
										</div>
									<?php endif ?>
									<h4 class="pricing__package-name"><?php echo wp_kses_post($item1['item_title']); ?></h4>
									<span class="pricing__package-price">
										<span class="pricing__package-currency"><?php echo wp_kses_post($item1['item_currency']); ?></span> <?php echo wp_kses_post($item1['item_price_1']); ?>
										<span class="pricing__package-period">.<?php echo wp_kses_post($item1['item_price_2']); ?></span>
									</span>
								</div>
								<div class="pricing__content">
									<div class="pricing__features-list">
										<ul>
											<?php echo wp_kses_post($item1['item_content']); ?>
										</ul>
									</div>
									<div class="pricing__btn lh-1">
										<a href="<?php echo wp_kses_post($item1['item_link_btn']); ?>" class="theme-btn">
											<?php echo wp_kses_post($item1['item_text_btn']); ?>
											<i class="fal fa-arrow-alt-right"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="tab-pane fade" id="yearly" role="tabpanel" aria-labelledby="yearly-tab">
				<div class="row">
					<?php 
					foreach ( $settings['tabs2'] as $item2 ) : 
					?>
						<div class="col-lg-4 col-md-6">
							<div class="pricing__box <?php echo wp_kses_post($item2['item_acitve']); ?> mb-50">
								<div class="pricing__header">
									<?php if ($item2['item_acitve'] == 'active'): ?>
										<div class="pricing__badge">
											<span><?php echo wp_kses_post($item2['item_text_active']); ?></span>
										</div>
									<?php endif ?>
									<h4 class="pricing__package-name"><?php echo wp_kses_post($item2['item_title']); ?></h4>
									<span class="pricing__package-price">
										<span class="pricing__package-currency"><?php echo wp_kses_post($item2['item_currency']); ?></span> <?php echo wp_kses_post($item2['item_price_1']); ?>
										<span class="pricing__package-period">.<?php echo wp_kses_post($item2['item_price_2']); ?></span>
									</span>
								</div>
								<div class="pricing__content">
									<div class="pricing__features-list">
										<ul>
											<?php echo wp_kses_post($item2['item_content']); ?>
										</ul>
									</div>
									<div class="pricing__btn lh-1">
										<a href="<?php echo wp_kses_post($item2['item_link_btn']); ?>" class="theme-btn">
											<?php echo wp_kses_post($item2['item_text_btn']); ?>
											<i class="fal fa-arrow-alt-right"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php
}

}