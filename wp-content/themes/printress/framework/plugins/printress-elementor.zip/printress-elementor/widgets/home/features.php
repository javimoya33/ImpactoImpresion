<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHomeFeatures extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-features';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home Features', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-pencil';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'homefeatures', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_home_features',
			[
				'label' => esc_html__( 'Home Features', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'background',
			[
				'label'       => esc_html__( 'Background Video Image', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Background Video Image', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'link_video',
			[
				'label'       => __( 'Link Video', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your link video', 'bdevs-elementor' ),
				'default'     => __( 'https://www.youtube.com/watch?v=Zu7MfPI3mKE', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'heading',
			[
				'label'       => __( 'Text Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text heading', 'bdevs-elementor' ),
				'default'     => __( 'Core Features', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Text Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text title', 'bdevs-elementor' ),
				'default'     => __( 'Download A Design Guideline', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_gl_title',
			[
				'label'       => __( 'Features Guideline Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your features guideline title', 'bdevs-elementor' ),
				'default'     => __( 'Grid Guideline', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_gl_text',
			[
				'label'       => __( 'Features Guideline Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your features guideline text', 'bdevs-elementor' ),
				'default'     => __( 'Features Guideline Text', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_f_title',
			[
				'label'       => __( 'Features File Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your features file title', 'bdevs-elementor' ),
				'default'     => __( 'Grid Guideline', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_f_text',
			[
				'label'       => __( 'Features File Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your features File text', 'bdevs-elementor' ),
				'default'     => __( 'Features File Text', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_bt_image1',
			[
				'label'       => esc_html__( 'Features Bottom Image 1', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Features Bottom Image 1', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'features_bt_image2',
			[
				'label'       => esc_html__( 'Features Bottom Image 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Features Bottom Image 2', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'features_bt_image3',
			[
				'label'       => esc_html__( 'Features Bottom Image 3', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Features Bottom Image 3', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'features_bt_text',
			[
				'label'       => __( 'Features Bottom Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your features bottom text', 'bdevs-elementor' ),
				'default'     => __( 'Features Bottom Text', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_book_image',
			[
				'label'       => esc_html__( 'Features Book Image', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Features Book Image', 'bdevs-elementor' ),
			]
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);



		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="bd-features black-bg p-relative">
	<div class="container">
		<div class="bd-features__box black-bg">
			<div class="row wow fadeInUp" data-wow-delay=".3s">
				<div class="col-xl-6 col-lg-6">
					<div class="bd-features__img p-relative w-img mb-60">
						<img src="<?php echo wp_kses_post($settings['background']['url']); ?>">
						<div class="bd-features__btn">
							<a class="play-btn popup-video" href="<?php echo wp_kses_post($settings['link_video']); ?>"><i class="far fa-play"></i></a>
						</div>
					</div>
				</div>
				<div class="col-xl-6 col-lg-6">
					<div class="bd-features__content mb-60">
						<div class="bd-section__title mb-40">
							<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>
								<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading']); ?></span>
							<?php endif; ?>
							<?php if (( '' !== $settings['title'] ) && ( $settings['show_title'] )): ?>
								<h2 class="bd__title white-color"><?php echo wp_kses_post($settings['title']); ?></h2>
							<?php endif; ?>
						</div>
						<div class="bd-features__content-inner d-flex">
							<div class="bd-features__gl mb-35">
								<h4 class="bd-features__gl-title"><?php echo wp_kses_post($settings['features_gl_title']); ?></h4>
								<div class="bd-features__gl-text">
									<?php echo wp_kses_post($settings['features_gl_text']); ?>
								</div>
							</div>
							<div class="bd-features__f mb-35">
								<h4 class="bd-features__f-title"><?php echo wp_kses_post($settings['features_f_title']); ?></h4>
								<?php echo wp_kses_post($settings['features_f_text']); ?>
							</div>
						</div>
						<div class="bd-features__bottom">
							<div class="bd-features__bottom-img f-left">
								<div class="bd-features__bottom-img1">
									<img src="<?php echo wp_kses_post($settings['features_bt_image1']['url']); ?>">
								</div>
								<div class="bd-features__bottom-img2">
									<img src="<?php echo wp_kses_post($settings['features_bt_image2']['url']); ?>">
								</div>
								<div class="bd-features__bottom-img3">
									<img src="<?php echo wp_kses_post($settings['features_bt_image3']['url']); ?>">
								</div>
							</div>
							<div class="bd-features__bottom-text fix">
								<h4><?php echo wp_kses_post($settings['features_bt_text']); ?></h4>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="bd-features__book-img wow fadeInUp" data-wow-delay=".3s">
				<img src="<?php echo wp_kses_post($settings['features_book_image']['url']); ?>">
			</div>
		</div>
	</div>
</section>

<?php
}
}