<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsHomeAbout extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-home-about';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home - About', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-info-circle';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'homeabout', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_home_about',
			[
				'label' => esc_html__( 'Home - About', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'heading',
			[
				'label'       => __( 'Text Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text about heading', 'bdevs-elementor' ),
				'default'     => __( 'About Us', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Text Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text about title', 'bdevs-elementor' ),
				'default'     => __( 'Priting Solutions For Your Company', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'content_1',
			[
				'label'       => __( 'Text Content 1', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text content', 'bdevs-elementor' ),
				'default'     => __( 'From finance, retail, and travel, to social media', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'about_img',
			[
				'label'       => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your About Image', 'bdevs-elementor' ),
			]	
		);
		$this->add_control(
			'content_2',
			[
				'label'       => __( 'Text Content 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text content', 'bdevs-elementor' ),
				'default'     => __( 'Complete Design Tookit-huge collection', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'about_list',
			[
				'label'       => __( 'Text List Content', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text content', 'bdevs-elementor' ),
				'default'     => __( '<li><i class="fal fa-check"></i> Request API Integration</li>', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'author_img',
			[
				'label'       => esc_html__( 'Author Image', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Author Image', 'bdevs-elementor' ),
			]	
		);
		$this->add_control(
			'author_text',
			[
				'label'       => __( 'Text Author', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text content', 'bdevs-elementor' ),
				'default'     => __( 'Miranda Helson', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'time_title',
			[
				'label'       => __( 'Time Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your time title', 'bdevs-elementor' ),
				'default'     => __( 'Working Hours', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'time_text',
			[
				'label'       => __( 'Text Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your time text', 'bdevs-elementor' ),
				'default'     => __( 'Those obsessed with print are not good the first requisite.', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'time_list',
			[
				'label'       => __( 'Time List', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text content', 'bdevs-elementor' ),
				'default'     => __( '<li><span class="day">Monday</span><span class="time">8 AM - 9 PM</span></li>', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);


		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="bd-about bd-about2 pt-95 pb-60">
	<div class="container">
		<div class="row wow fadeInUp" data-wow-delay=".3s">
			<div class="col-lg-12">
				<div class="bd-section__title mb-60">
					<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>
						<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading']); ?></span>
					<?php endif; ?>
					<?php if (( '' !== $settings['title'] ) && ( $settings['show_title'] )): ?>
						<h2 class="bd__title"><?php echo wp_kses_post($settings['title']); ?></h2>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<div class="row bd-about2__wrapper wow fadeInUp" data-wow-delay=".5s">
			<div class="col-xxl-5 col-xl-4 col-lg-4">
				<div class="bd-about2__img br-img-6 w-img mb-60">
					<p><?php echo wp_kses_post($settings['content_1']); ?></p>
					<img src="<?php echo wp_kses_post($settings['about_img']['url']); ?>" alt="About">
				</div>
			</div>
			<div class="col-xxl-4 col-xl-4 col-lg-4">
				<div class="bd-about2__list-wrapper mb-60">
					<p><?php echo wp_kses_post($settings['content_2']); ?></p>
					<div class="bd-about2__list">
						<ul>
							<?php echo wp_kses_post($settings['about_list']); ?>
						</ul>
					</div>
					<div class="bd-about2__author">
						<div class="bd-about2__author-img">
							<img src="<?php echo wp_kses_post($settings['author_img']['url']); ?>" alt="author">
						</div>
						<div class="bd-about2__text">
							<?php echo wp_kses_post($settings['author_text']); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xxl-3 col-xl-4 col-lg-4">
				<div class="bd-about2__sc mb-60">
					<h3 class="bd-about2__sc-title"><?php echo wp_kses_post($settings['time_title']); ?></h3>
					<p class="bd-about2__sc-text"><?php echo wp_kses_post($settings['time_text']); ?></p>
					<div class="bd-about2__sc-list">
						<ul>
							<?php echo wp_kses_post($settings['time_list']); ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
}

}