<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsTeamForm extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-team-form';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Team - Form', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'teamform', 'carousel' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
		$position_options = [
			''              => esc_html__('Default', 'bdevs-elementor'),
			'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
			'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
			'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
			'center'        => esc_html__('Center', 'bdevs-elementor') ,
			'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
			'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
			'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
			'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') , 
			'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
		];

		return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_team_form',
			[
				'label' => esc_html__( 'Team - Form', 'bdevs-elementor' ),
			]
		);
		$this->add_control(
			'team_img',
			[
				'label'       => esc_html__( 'Team Image', 'bdevs-elementor' ),
				'type'        => Controls_Manager::MEDIA,
				'dynamic'     => [ 'active' => true ],
				'label_block' => true,
				'description' => esc_html__( 'Upload Your Team Image', 'bdevs-elementor' ),
			]	
		);
		$this->add_control(
			'heading_form',
			[
				'label'       => __( 'Text Team Form Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your text Team form heading', 'bdevs-elementor' ),
				'default'     => __( 'Contact Us', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'title_form',
			[
				'label'       => __( 'Text Team Form Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your text team form title', 'bdevs-elementor' ),
				'default'     => __( 'Give Us A Printing <br> Deal From Company', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);
		$this->add_control(
			'shortcode_form',
			[
				'label'       => __( 'Shortcode team Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your shortcode contact form', 'bdevs-elementor' ),
				'default'     => __( '[contact-form-7 id="124" title="Contact Form"]', 'bdevs-elementor' ),
				'label_block' => true,
			]	
		);


		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);


		$this->add_control(
			'show_img',
			[
				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_heading_form',
			[
				'label'   => esc_html__( 'Show Heading Form', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_title_form',
			[
				'label'   => esc_html__( 'Show Title Form', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {

		$settings  = $this->get_settings_for_display();
		extract($settings);
		?> 

<section class="bd-contact2 p-relative">	
<?php if (( '' !== $settings['team_img']['url'] ) && ( $settings['show_img'] )): ?>
	<div class="bd-contact2__img p-absolute">
		<img src="<?php echo wp_kses_post($settings['team_img']['url']); ?>" alt="contact image">
	</div>
<?php endif; ?>
	<div class="container">
		<div class="row justify-content-end wow fadeInUp" data-wow-delay=".3s">
		<?php if (( '' !== $settings['team_img']['url'] ) && ( $settings['show_img'] )) { ?>
			<div class="col-lg-6">
				<div class="bd-contact2__wrapper mb-120">
		<?php } else { ?>
			<div class="col-lg-12">
				<div class="pt-120 mb-120">
		<?php } ?>
					<div class="bd-section__title mb-40">
						<?php if (( '' !== $settings['heading_form'] ) && ( $settings['show_heading_form'] )): ?>
							<span class="bd__subtitle"><?php echo wp_kses_post($settings['heading_form']); ?></span>
						<?php endif; ?>
						<?php if (( '' !== $settings['title_form'] ) && ( $settings['show_title_form'] )): ?>
							<h2 class="bd__title-sm"><?php echo wp_kses_post($settings['title_form']); ?></h2>
						<?php endif; ?>
					</div>
					<div class="bd-contact__wrapper">
						<div class="bd-contact__form">
							<?php echo do_shortcode($settings['shortcode_form']); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php
}

}