<?php
namespace Elementor\Core\Editor\Templates;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

<div id="elementor-editor-wrapper-v2"></div>

<?php include __DIR__ . '/editor-body-v1.view.php'; ?>
